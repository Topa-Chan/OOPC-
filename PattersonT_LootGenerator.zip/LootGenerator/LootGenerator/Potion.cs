﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LootGenerator
{
    public class Potion : Item
    {
        private int HealAmount { get; set; }

        public Potion(int healAmount) : base("Health Potion", (healAmount/10))
        {
            HealAmount = healAmount;
        }

        public override string ToString()
        {
            return $"{base.ToString()}\tHP: {HealAmount}";
        }
    }
}
