﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CSC150_ConsoleMenu;

namespace LootGenerator
{
    public class LootGenerator
    {
        public static List<string> menu = new List<string>() { "Generator 1 Loot Item.", "Generate Some Loot Items.", "Generate n  Loot Items." };
        public static Random rand = new Random();
        public static List<Item> loot = new List<Item>();

        public static void Run()
        {
            int choice = CIO.PromptForMenuSelection(menu, true);
            switch (choice)
            {
                case 1:
                    GenerateLoots(1);
                    break;
                case 2:
                    GenerateLoots(rand.Next(1, 11));
                    break;
                case 3:
                    int n = GenerateN();
                    GenerateLoots(n);
                    break;
                default:
                    break;
            }
        }

        public static void GenerateLoots(int l)
        {
            Console.WriteLine();
            Console.WriteLine("Generating loot!");
            int gen;
            for (int i = 0; i < l; i++)
            {
                gen = rand.Next(4);
                switch(gen)
                {
                    case 0:
                        loot.Add(ItemGen());
                        break;
                    case 1:
                        loot.Add(HealGenerator());
                        break;
                    case 2:
                        loot.Add(DamagerGenerator());
                        break;
                    case 3:
                        loot.Add(ArmourGenerator());
                        break;
                    default:
                        break;
                }
            }
            DisplayLoot(loot);
        }

        public static void DisplayLoot(List<Item> loots)
        {
            foreach (Item lootItem in loots)
            {
                Console.WriteLine(lootItem + "\n");
            }
            Run();
        }

        public static int GenerateN()
        {
            int loot = CIO.PromptForInt("Please entre the number of loot you would like to recieve: ", 1, int.MaxValue);
            return loot;
        }

        public static Potion HealGenerator()
        {
            int heals = rand.Next(10, 101);
            Potion p = new Potion(heals);
            return p;
        }

        public static Weapon DamagerGenerator()
        {
            List<string> Name = new List<string>
            { "Krebs Furby",
                "Short Sword",
                "Bo Staff",
                "Nunchucks",
                "Choco Taco",
                "Silver Fork",
                "Golden Fork",
                "Icy Bubble",
                "Love-Me-Knot Chain",
                "Portal Gun",
                "Pop Figure",
                "Left Shoe",
                "Katana",
                "Dagger",
                "Light Sabre",
                "Dagger"
            };
            string name = Name[rand.Next(Name.Count)];
            int value = rand.Next(1, 501);
            int damageMin = rand.Next(1, 100);
            int damageMax = rand.Next(damageMin, 101);
            Weapon w = new Weapon(damageMin, damageMax, name, value);
            return w;
        }

        public static Armour ArmourGenerator()
        {
            List<string> Name = new List<string>
            {
                "Origami Paper",
                "Platemail",
                "Chainmail",
                "Dragonskin",
                "Lizardskin",
                "Leather",
                "Rubber",
                "Cloth",
                "Gold"
            };
            string name = Name[rand.Next(Name.Count)];
            int value = rand.Next(10, 1501);
            int armourRating = rand.Next(8, 18);
            int damageReduction = rand.Next(0, 11);
            int agilityModifier = rand.Next(-6, 0);
            Armour a = new Armour(armourRating, damageReduction, agilityModifier, name, value);
            return a;
        }

        public static Item ItemGen()
        {
            List<string> Name = new List<string>
            {
                "Bucket",
                "Mouse",
                "String",
                "Nickle",
                "Potato",
                "Phone",
                "Taco",
                "Flannel",
                "ID",
                "Polisher",
                "Diamond",
                "CD",
                "Marker",
                "Paper"
            };
            string name = Name[rand.Next(Name.Count)];
            int value = rand.Next(0, 25);
            Item i = new Item(name, value);
            return i;
        }
    }
}
