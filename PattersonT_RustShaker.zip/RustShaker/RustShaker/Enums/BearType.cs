﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RustShaker.Enums
{
    public enum BearType
    {
        Black,
        Gummy,
        Polar,
        Grizl,
        Brown,
        Sloth,
        Kodiak,
        Care,
        Lava,
        Dunno
    }
}
