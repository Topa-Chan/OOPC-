﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RustShaker
{
    class Program
    {


        public static void Main(string[] args)
        {
            RustShaker.BuildBear create = new RustShaker.BuildBear();
            create.Run();
        }

        //public void Run()
        //{
        //    create.Run();
        //}
    }
}
